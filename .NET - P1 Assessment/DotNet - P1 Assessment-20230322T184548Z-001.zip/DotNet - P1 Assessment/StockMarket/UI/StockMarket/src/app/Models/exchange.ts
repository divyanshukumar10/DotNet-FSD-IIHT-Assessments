export class Exchange {
    Id:number;
    StockExchangeName:string;
    Brief:string;
    ContactAddress:string;
    Remarks:string;
}
