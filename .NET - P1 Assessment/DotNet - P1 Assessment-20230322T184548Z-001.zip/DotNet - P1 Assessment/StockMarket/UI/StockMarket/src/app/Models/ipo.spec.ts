import { Ipo } from './ipo';

describe('Ipo', () => {
  it('should create an instance', () => {
    expect(new Ipo()).toBeTruthy();
  });
});
