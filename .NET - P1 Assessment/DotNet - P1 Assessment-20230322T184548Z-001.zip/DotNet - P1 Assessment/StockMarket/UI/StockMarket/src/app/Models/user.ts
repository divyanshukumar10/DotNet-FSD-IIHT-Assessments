export class User {
    UserName:string="";
    Password:string="";
    UserType:string="";
    Email:string="";
    MobileNo:string="";
    Confirmed:string="";
}
