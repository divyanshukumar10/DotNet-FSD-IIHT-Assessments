import { Exchange } from './exchange';

describe('Exchange', () => {
  it('should create an instance', () => {
    expect(new Exchange()).toBeTruthy();
  });
});
