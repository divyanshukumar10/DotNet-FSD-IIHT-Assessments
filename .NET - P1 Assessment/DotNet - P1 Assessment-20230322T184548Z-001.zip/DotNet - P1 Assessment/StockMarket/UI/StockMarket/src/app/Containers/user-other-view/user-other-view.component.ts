import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-other-view',
  templateUrl: './user-other-view.component.html',
  styleUrls: ['./user-other-view.component.css']
})
export class UserOtherViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
