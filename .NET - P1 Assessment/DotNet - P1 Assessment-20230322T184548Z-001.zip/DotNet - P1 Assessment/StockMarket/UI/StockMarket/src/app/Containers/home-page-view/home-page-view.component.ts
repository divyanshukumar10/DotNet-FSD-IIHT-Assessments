import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-view',
  templateUrl: './home-page-view.component.html',
  styleUrls: ['./home-page-view.component.css']
})
export class HomePageViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
