﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMarket.AccountAPI
{
    public class Token
    {
        public string userType { get; set; }
        public string uname { get; set; }
        public string token { get; set; }
    }
}
