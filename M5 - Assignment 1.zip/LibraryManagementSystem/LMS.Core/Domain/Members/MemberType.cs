﻿namespace LMS.Core.Domain.Members
{
    public enum MemberType
    {
        Student = 1,
        Teacher = 2,
        Staff = 3
    }
}
