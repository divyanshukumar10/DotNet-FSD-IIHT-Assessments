﻿namespace HealthChecksSample.Snippets;

public class SampleHealthCheckWithDiConfig
{
    public Uri? BaseUriToCheck { get; set; }
}
