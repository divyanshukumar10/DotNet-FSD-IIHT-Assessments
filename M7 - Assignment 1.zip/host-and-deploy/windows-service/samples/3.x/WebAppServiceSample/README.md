# ASP.NET Core Windows Service Sample

This sample shows how to host an ASP.NET Core app as a Windows Service without using IIS. This sample demonstrates the scenario described in [Host ASP.NET Core in a Windows Service](https://learn.microsoft.com/aspnet/core/host-and-deploy/windows-service).

After establishing and starting the service, access the app in a browser at `http://localhost:5000/`.
