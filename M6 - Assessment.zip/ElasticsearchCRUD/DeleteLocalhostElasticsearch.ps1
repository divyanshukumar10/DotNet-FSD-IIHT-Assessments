Invoke-WebRequest http://localhost:9200/* -Method delete | Out-Null
