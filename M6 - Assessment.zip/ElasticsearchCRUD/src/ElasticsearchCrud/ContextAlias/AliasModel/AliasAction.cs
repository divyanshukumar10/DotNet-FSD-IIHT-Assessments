namespace ElasticsearchCRUD.ContextAlias.AliasModel
{
	public enum AliasAction
	{
		remove,
		add,
	}
}