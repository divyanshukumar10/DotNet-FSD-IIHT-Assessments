﻿namespace ElasticsearchCRUD.Model
{
	public static class DefaultCharFilters
	{
		public const string Mapping = "mapping";
		public const string HtmlStrip = "html_strip";
		public const string PatternReplace = "pattern_replace";
		public const string IcuNormalizer = "icu_normalizer";
	}
}