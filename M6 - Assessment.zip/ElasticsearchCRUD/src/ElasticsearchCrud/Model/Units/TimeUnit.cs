﻿namespace ElasticsearchCRUD.Model.Units
{
	public abstract class TimeUnit
	{
		public abstract string GetTimeUnit();
	}
}