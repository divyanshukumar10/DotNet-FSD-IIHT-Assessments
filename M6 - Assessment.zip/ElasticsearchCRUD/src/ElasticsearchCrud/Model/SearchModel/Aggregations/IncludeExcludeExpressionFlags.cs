﻿namespace ElasticsearchCRUD.Model.SearchModel.Aggregations
{
	public enum IncludeExcludeExpressionFlags
	{
		CANON_EQ, CASE_INSENSITIVE, COMMENTS, DOTALL, LITERAL, MULTILINE, UNICODE_CASE, UNICODE_CHARACTER_CLASS, UNIX_LINES
	}
}