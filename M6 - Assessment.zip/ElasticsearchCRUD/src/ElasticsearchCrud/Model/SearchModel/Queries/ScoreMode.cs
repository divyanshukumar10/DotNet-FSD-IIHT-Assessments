﻿namespace ElasticsearchCRUD.Model.SearchModel.Queries
{
	public enum ScoreMode
	{
		avg, 
		sum, 
		max,
		none
	}
}