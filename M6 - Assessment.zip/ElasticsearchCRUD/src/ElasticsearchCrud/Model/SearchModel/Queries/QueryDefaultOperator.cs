﻿namespace ElasticsearchCRUD.Model.SearchModel.Queries
{
	public enum QueryDefaultOperator
	{
		AND,
		OR
	}
}