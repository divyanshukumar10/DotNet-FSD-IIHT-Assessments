﻿namespace ElasticsearchCRUD.Model.SearchModel.Queries
{
	public interface ISpanQuery : IQuery
	{
	}
}