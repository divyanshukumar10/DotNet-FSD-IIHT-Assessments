namespace ElasticsearchCRUD.Model.SearchModel.Sorting
{
	public enum OrderEnum
	{
		asc,
		desc
	}
}