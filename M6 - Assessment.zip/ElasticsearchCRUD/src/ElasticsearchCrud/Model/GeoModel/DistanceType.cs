﻿namespace ElasticsearchCRUD.Model.GeoModel
{
	public enum DistanceType
	{
		sloppy_arc,
		arc,
		plane
	}
}