namespace ElasticsearchCRUD.Model.GeoModel
{
	public enum DistanceUnitEnum
	{
		miles, yards, feet, inch, km, m, cm, mm, nmi
	}
}