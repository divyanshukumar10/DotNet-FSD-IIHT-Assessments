namespace ElasticsearchCRUD.ContextSearch.SearchModel.AggModel
{
	public class StdDeviationBounds
	{
		public double Upper { get; set; }
		public double Lower { get; set; }
	}
}