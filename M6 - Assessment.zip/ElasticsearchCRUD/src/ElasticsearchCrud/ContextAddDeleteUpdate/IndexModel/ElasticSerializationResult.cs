﻿namespace ElasticsearchCRUD.ContextAddDeleteUpdate.IndexModel
{
	public class ElasticSerializationResult
	{
		public IndexMappings IndexMappings { get; set; }

		public string Content { get; set; }
	}
}
