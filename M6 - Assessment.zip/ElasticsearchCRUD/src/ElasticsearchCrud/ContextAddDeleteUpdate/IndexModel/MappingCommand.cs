namespace ElasticsearchCRUD.ContextAddDeleteUpdate.IndexModel
{
	public class MappingCommand
	{
		public string RequestType { get; set; }
		public string Url { get; set; }
		public string Content { get; set; }
	}
}